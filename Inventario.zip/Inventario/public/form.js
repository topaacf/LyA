document.addEventListener("DOMContentLoaded", () => {
    // Verificar si el usuario está autenticado
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        alert("Por favor, inicia sesión para continuar.");
        window.location.href = "index.html";
        return;
    }

    const editingItem = JSON.parse(localStorage.getItem("editingItem"));

    // Referencias a los campos del formulario
    const formTitle = document.getElementById("form-title");
    const itemNameInput = document.getElementById("item-name");
    const itemDescriptionInput = document.getElementById("item-description");
    const itemCodeInput = document.getElementById("item-code");
    const itemBrandInput = document.getElementById("item-brand");
    const itemLocationInput = document.getElementById("item-location");
    const itemConditionSelect = document.getElementById("item-condition");
    const itemImageInput = document.getElementById("item-image");
    const isPrinterCheckbox = document.getElementById("is-printer");
    const tonerTypeInput = document.getElementById("toner-type");
    const tonerTypeContainer = document.getElementById("toner-type-container");
    const saveButton = document.getElementById("save-item");
    const cancelButton = document.getElementById("cancel");
    const itemUsuarioInput = document.getElementById("item-usuario");
    const itemModelInput = document.getElementById("item-model");

    // Si estamos editando un objeto, rellenar el formulario con los datos existentes
    if (editingItem) {
        if (formTitle) formTitle.textContent = "Editar Mobiliario";
        if (itemNameInput) itemNameInput.value = editingItem.name || "";
        if (itemDescriptionInput) itemDescriptionInput.value = editingItem.description || "";
        if (itemCodeInput) itemCodeInput.value = editingItem.code || "";
        if (itemBrandInput) itemBrandInput.value = editingItem.brand || "";
        if (itemLocationInput) itemLocationInput.value = editingItem.location || "";
        if (itemConditionSelect) itemConditionSelect.value = editingItem.condition || "";
        if (isPrinterCheckbox) isPrinterCheckbox.checked = !!editingItem.isPrinter;
        if (tonerTypeInput) tonerTypeInput.value = editingItem.toner || "";
        if (tonerTypeContainer) tonerTypeContainer.style.display = editingItem.isPrinter ? "block" : "none";
        if (itemUsuarioInput) itemUsuarioInput.value = editingItem.usuario || "";
        if (itemModelInput) itemModelInput.value = editingItem.modelo || "";
        if (document.getElementById("item-model")) document.getElementById("item-model").value = editingItem.modelo || "";

        // Mostrar imágenes actuales
        const currentImagesDiv = document.getElementById("current-images");
        currentImagesDiv.innerHTML = "";

        // Imagen principal
        if (editingItem.imageUrl) {
            const img = document.createElement("img");
            img.src = editingItem.imageUrl;
            img.style = "width:100px;height:100px;object-fit:cover;margin-right:8px;border-radius:8px;border:2px solid #007b8a;";
            img.title = "Imagen principal";
            // Botón eliminar principal
            const delBtn = document.createElement("button");
            delBtn.textContent = "Eliminar";
            delBtn.style = "margin-left:6px;";
            delBtn.onclick = () => {
                editingItem.imageUrl = "";
                currentImagesDiv.removeChild(wrapper);
            };
            const wrapper = document.createElement("div");
            wrapper.style = `
                display: inline-flex;
                flex-direction: column;
                align-items: center;
                margin: 0 18px 18px 0;
                min-width: 110px;
            `;
            img.style.marginRight = "0"; // Elimina el margin-right del img si lo tienes
            delBtn.style = `
                margin-top: 10px;
                margin-left: 0;
                padding: 6px 16px;
                border-radius: 8px;
                background: #38b2ac;
                color: #fff;
                border: none;
                cursor: pointer;
            `;
            wrapper.appendChild(img);
            wrapper.appendChild(delBtn);
            currentImagesDiv.appendChild(wrapper);
        }

        // Imágenes secundarias
        if (Array.isArray(editingItem.secondaryImages)) {
            editingItem.secondaryImages.forEach((imgSrc, idx) => {
                const img = document.createElement("img");
                img.src = imgSrc;
                img.style = "width:100px;height:100px;object-fit:cover;margin-right:8px;border-radius:8px;border:2px solid #aaa;";
                img.title = "Imagen secundaria";
                // Botón eliminar secundaria
                const delBtn = document.createElement("button");
                delBtn.textContent = "Eliminar";
                delBtn.style = "margin-left:6px;";
                delBtn.onclick = () => {
                    editingItem.secondaryImages.splice(idx, 1);
                    currentImagesDiv.removeChild(wrapper);
                };
                const wrapper = document.createElement("div");
                wrapper.style = `
                    display: inline-flex;
                    flex-direction: column;
                    align-items: center;
                    margin: 0 18px 18px 0;
                    min-width: 110px;
                `;
                img.style.marginRight = "0"; // Elimina el margin-right del img si lo tienes
                delBtn.style = `
                    margin-top: 10px;
                    margin-left: 0;
                    padding: 6px 16px;
                    border-radius: 8px;
                    background: #38b2ac;
                    color: #fff;
                    border: none;
                    cursor: pointer;
                `;
                wrapper.appendChild(img);
                wrapper.appendChild(delBtn);
                currentImagesDiv.appendChild(wrapper);
            });
        }
    } else {
        if (tonerTypeContainer) tonerTypeContainer.style.display = "none";
    }

    // Mostrar/ocultar campo de tóner según el checkbox
    if (isPrinterCheckbox && tonerTypeContainer) {
        isPrinterCheckbox.addEventListener("change", function() {
            tonerTypeContainer.style.display = this.checked ? "block" : "none";
        });
    }

    // Manejar el submit del formulario (único punto de guardado)
    const itemForm = document.getElementById("item-form");
    if (itemForm) {
        itemForm.addEventListener("submit", async function(e) {
            e.preventDefault();

            // Carga inventario y editingItem
            let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
            const editingItem = JSON.parse(localStorage.getItem("editingItem"));

            // Obtén referencias a los campos
            const fields = [
                { id: "item-name", label: "Nombre del Mobiliario" },
                { id: "item-description", label: "Descripción del Mobiliario" },
                { id: "item-code", label: "Código del Mobiliario" },
                { id: "item-brand", label: "Marca del Mobiliario" },
                { id: "item-model", label: "Modelo del mobiliario" },
                { id: "item-location", label: "Ubicación" },
                { id: "item-condition", label: "Estado" },
                { id: "is-printer", label: "¿Es impresora?" },
                { id: "item-usuario", label: "Usuario responsable" }
            ];
            let missing = [];
            let refs = {};
            fields.forEach(f => {
                refs[f.id] = document.getElementById(f.id);
                if (!refs[f.id]) missing.push(f.label + " (id: " + f.id + ")");
            });

            // Solo validar toner-type si es impresora
            const isPrinterChecked = refs["is-printer"] && refs["is-printer"].checked;
            let tonerTypeRef = document.getElementById("toner-type");
            if (isPrinterChecked && !tonerTypeRef) {
                missing.push("Tipo de tóner (id: toner-type)");
            }

            if (missing.length > 0) {
                alert("Faltan los siguientes campos en el formulario o su id es incorrecto:\n\n" + missing.join("\n"));
                return;
            }

            // Validación final: si algún campo sigue siendo null, muestra error y detén
            for (const key in refs) {
                if (!refs[key]) {
                    alert(`El campo con id "${key}" no existe en el HTML. Corrige el formulario.`);
                    return;
                }
            }

            // Lee campos (ya seguro que existen)
            const item = {
                id: editingItem ? editingItem.id : Date.now(),
                name: refs["item-name"].value,
                description: refs["item-description"].value,
                code: refs["item-code"].value,
                brand: refs["item-brand"].value,
                modelo: refs["item-model"].value,
                location: refs["item-location"].value,
                condition: refs["item-condition"].value,
                isPrinter: refs["is-printer"].checked,
                toner: isPrinterChecked && tonerTypeRef ? tonerTypeRef.value : "",
                usuario: refs["item-usuario"].value,
            };

            // Imagen principal
            const principalInput = document.getElementById("item-image-principal");
            if (principalInput.files && principalInput.files[0]) {
                item.imageUrl = await uploadImage(principalInput.files[0]);
            } else if (editingItem && editingItem.imageUrl) {
                item.imageUrl = editingItem.imageUrl;
            } else {
                item.imageUrl = "";
            }

            // Imágenes secundarias (máximo 3)
            item.secondaryImages = [];
            const secundariasInput = document.getElementById("item-images-secundarias");
            if (secundariasInput.files && secundariasInput.files.length > 0) {
                if (secundariasInput.files.length > 3) {
                    alert("Máximo 3 imágenes secundarias.");
                    return;
                }
                for (let file of secundariasInput.files) {
                    item.secondaryImages.push("imagenes/" + file.name);
                }
            } else if (editingItem && editingItem.secondaryImages) {
                item.secondaryImages = editingItem.secondaryImages;
            }

            // Guardar: si edición, reemplaza; si nuevo, agrega
            if (editingItem) {
                const idx = inventory.findIndex(i => i.id == editingItem.id);
                if (idx !== -1) {
                    inventory[idx] = item;
                }
            } else {
                // Usa los mismos campos validados arriba
                inventory.push(item);
            }

            localStorage.setItem("inventory", JSON.stringify(inventory));
            localStorage.removeItem("editingItem");
            window.location.href = "index.html";
        });
    }

    // Cancelar
    if (cancelButton) {
        cancelButton.addEventListener("click", (e) => {
            e.preventDefault();
            window.location.href = "index.html";
        });
    }

    function saveItem(name, location, condition, imageUrl, modelo) {
        const description = itemDescriptionInput.value.trim();
        const code = itemCodeInput.value.trim();
        const brand = itemBrandInput.value.trim();
        const isPrinter = isPrinterCheckbox.checked;
        const toner = isPrinter ? tonerTypeInput.value.trim() : "";
        const usuario = itemUsuarioInput.value.trim();

        const newItem = {
            id: editingItem ? editingItem.id : Date.now(),
            name,
            description,
            code,
            brand,
            location,
            condition,
            imageUrl,
            isPrinter,
            toner,
            usuario,
            modelo
        };

        let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
        if (editingItem) {
            const index = inventory.findIndex(item => item.id === editingItem.id);
            if (index !== -1) {
                inventory[index] = newItem;
            }
        } else {
            inventory.push(newItem);
        }

        localStorage.setItem("inventory", JSON.stringify(inventory));
        localStorage.removeItem("editingItem");
        alert("Mobiliario guardado exitosamente.");
        window.location.href = "index.html";
    }

    // Logout desde el formulario
    const logoutBtn = document.getElementById("logout");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("isLoggedIn");
            window.location.href = "index.html";
        });
    }

    if (localStorage.getItem("userRole") === "read") {
        document.getElementById("item-form").querySelectorAll("input, select, textarea, button[type='submit']").forEach(el => {
            el.disabled = true;
        });
        // Opcional: muestra un mensaje
        const msg = document.createElement("div");
        msg.textContent = "Solo lectura: no puedes editar ni agregar mobiliario.";
        msg.style.color = "red";
        document.getElementById("form-container").prepend(msg);
    }

    const addSecondaryBtn = document.getElementById("add-secondary-image-btn");
    const addSecondaryInput = document.getElementById("add-secondary-image-input");

    function updateAddSecondaryBtn() {
        // Solo muestra el botón si hay menos de 3 imágenes secundarias y editingItem existe
        if (editingItem && editingItem.secondaryImages && editingItem.secondaryImages.length < 3) {
            addSecondaryBtn.style.display = "inline-block";
        } else {
            addSecondaryBtn.style.display = "none";
        }
    }
    updateAddSecondaryBtn();

    addSecondaryBtn.onclick = () => {
        addSecondaryInput.value = ""; // Limpiar selección previa
        addSecondaryInput.click();
    };

    addSecondaryInput.onchange = async function () {
        if (!this.files || !this.files[0]) return;
        const file = this.files[0];

        // Sube la imagen secundaria al backend y guarda la ruta
        try {
            const imageUrl = await uploadImage(file);

            editingItem.secondaryImages = editingItem.secondaryImages || [];
            if (editingItem.secondaryImages.length < 3) {
                editingItem.secondaryImages.push(imageUrl);

                // Actualiza el objeto en localStorage
                localStorage.setItem("editingItem", JSON.stringify(editingItem));

                // Si ya existe en el inventario, actualízalo también
                let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
                const idx = inventory.findIndex(i => i.id === editingItem.id);
                if (idx !== -1) {
                    inventory[idx].secondaryImages = editingItem.secondaryImages;
                    localStorage.setItem("inventory", JSON.stringify(inventory));
                }

                location.reload();
            } else {
                alert("Solo puedes tener hasta 3 imágenes secundarias.");
            }
        } catch (err) {
            alert("Error al subir la imagen secundaria.");
        }
    };

    const fileInput = document.getElementById("image-input");
    let imageUrl = "";
    if (fileInput && fileInput.files.length > 0) {
        // Solo guarda la ruta relativa
        imageUrl = "imagenes/" + fileInput.files[0].name;
        // Aquí deberías copiar el archivo a la carpeta 'imagenes' si usas backend o Electron
    }
    // ...guardar el objeto en el inventario usando imageUrl...
});

async function getBase64(file) {
    return new Promise((resolve, reject) => {
        if (!file) return resolve("");
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function compressImage(file, maxWidth = 800, quality = 0.7, callback) {
    const reader = new FileReader();
    reader.onload = function(event) {
        const img = new Image();
        img.onload = function() {
            // Redimensionar si es necesario
            let width = img.width;
            let height = img.height;
            if (width > maxWidth) {
                height *= maxWidth / width;
                width = maxWidth;
            }
            // Dibujar en canvas
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);
            // Comprimir a JPEG (puedes cambiar a 'image/png' si prefieres)
            const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
            callback(compressedDataUrl);
        };
        img.src = event.target.result;
    };
    reader.readAsDataURL(file);
}

async function getCompressedBase64(file) {
    return new Promise((resolve, reject) => {
        compressImage(file, 800, 0.6, (compressedDataUrl) => {
            // Comprobar tamaño en base64 (~1.37 * bytes)
            const sizeKB = Math.round((compressedDataUrl.length * 3 / 4) / 1024);
            if (sizeKB > 300) {
                reject("La imagen es demasiado grande tras comprimir (máx 300KB).");
            } else {
                resolve(compressedDataUrl);
            }
        });
    });
}

async function uploadImage(file) {
    const formData = new FormData();
    formData.append('image', file);

    const response = await fetch('http://localhost:3000/upload', {
        method: 'POST',
        body: formData
    });
    const data = await response.json();
    console.log("Respuesta del backend al subir imagen:", data);
    return data.imageUrl; // Ruta relativa para guardar en el inventario
}