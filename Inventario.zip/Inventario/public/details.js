let selectedItem = null;

document.addEventListener("DOMContentLoaded", () => {
    // Verificar si el usuario está autenticado
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (isLoggedIn !== "true") {
        alert("Por favor, inicia sesión para continuar.");
        window.location.href = "index.html";
        return;
    }

    selectedItem = JSON.parse(localStorage.getItem("selectedItem"));
    if (!selectedItem) {
        window.location.href = "index.html";
        return;
    }

    // Mostrar datos en los campos de detalles
    if (document.getElementById("detail-name")) document.getElementById("detail-name").textContent = selectedItem.name || "";
    if (document.getElementById("detail-description")) document.getElementById("detail-description").textContent = selectedItem.description || "";
    if (document.getElementById("detail-code")) document.getElementById("detail-code").textContent = selectedItem.code || "";
    if (document.getElementById("detail-brand")) document.getElementById("detail-brand").textContent = selectedItem.brand || "";
    if (document.getElementById("detail-location")) document.getElementById("detail-location").textContent = selectedItem.location || "";
    if (document.getElementById("detail-condition")) document.getElementById("detail-condition").textContent = selectedItem.condition || "";
    if (document.getElementById("detail-printer")) document.getElementById("detail-printer").textContent = selectedItem.isPrinter ? "Sí" : "No";

    // Mostrar/ocultar el campo de tóner según si es impresora
    const tonerRow = document.getElementById("detail-toner") ? document.getElementById("detail-toner").parentElement : null;
    if (tonerRow) {
        if (selectedItem.isPrinter && selectedItem.toner) {
            document.getElementById("detail-toner").textContent = selectedItem.toner;
            tonerRow.style.display = "flex";
        } else {
            document.getElementById("detail-toner").textContent = "";
            tonerRow.style.display = "none";
        }
    }

    if (document.getElementById("detalle-modelo")) document.getElementById("detalle-modelo").textContent = selectedItem.modelo || "Sin modelo";
    if (document.getElementById("detalle-usuario")) document.getElementById("detalle-usuario").textContent = selectedItem.usuario || "Sin usuario asignado";

    // ----------- NUEVA GALERÍA (tipo Amazon) -----------
    const galleryImages = [selectedItem.imageUrl, ...(selectedItem.secondaryImages || [])].filter(Boolean);
    const mainImage = document.getElementById("main-image");
    const thumbnails = document.getElementById("thumbnails");
    const zoomLens = document.getElementById("zoom-lens");
    const mainImageContainer = document.getElementById("main-image-container");
    const moreIndicator = document.getElementById("more-indicator");

    let currentIdx = 0;

    function showImage(idx) {
        currentIdx = idx;
        if (mainImage) mainImage.src = galleryImages[idx];
        if (thumbnails) {
            thumbnails.querySelectorAll("img").forEach((img, i) => {
                img.style.border = i === idx ? "2px solid #007b8a" : "2px solid transparent";
                img.style.opacity = i === idx ? "1" : "0.7";
            });
        }
    }

    // Render thumbnails
    if (thumbnails) {
        thumbnails.innerHTML = "";
        galleryImages.forEach((imgSrc, idx) => {
            if (idx < 5) {
                const thumb = document.createElement("img");
                thumb.src = imgSrc;
                thumb.style = "width:70px;height:70px;object-fit:cover;border-radius:6px;cursor:pointer;border:2px solid transparent;transition:all 0.2s;";
                thumb.onclick = () => showImage(idx);
                thumbnails.appendChild(thumb);
            }
        });
    }

    // Indicador de más imágenes
    if (moreIndicator) {
        if (galleryImages.length > 5) {
            moreIndicator.style.display = "block";
            moreIndicator.textContent = `+${galleryImages.length - 5} más`;
        } else {
            moreIndicator.style.display = "none";
        }
    }

    if (galleryImages.length > 0 && mainImage) showImage(0);

    // Zoom al pasar el mouse
    if (mainImageContainer && zoomLens && mainImage) {
        mainImageContainer.onmousemove = function(e) {
            zoomLens.style.display = "block";
            const rect = mainImage.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            zoomLens.style.left = Math.max(0, Math.min(rect.width - 120, x - 60)) + "px";
            zoomLens.style.top = Math.max(0, Math.min(rect.height - 120, y - 60)) + "px";
            zoomLens.style.background = `url('${galleryImages[currentIdx]}') no-repeat`;
            zoomLens.style.backgroundSize = `${rect.width * 2}px ${rect.height * 2}px`;
            zoomLens.style.backgroundPosition = `-${(x - 60) * 2}px -${(y - 60) * 2}px`;
        };
        mainImageContainer.onmouseleave = function() {
            zoomLens.style.display = "none";
        };
    }
    // ----------- FIN NUEVA GALERÍA -----------

    // Botón editar
    const editBtn = document.getElementById("edit-item");
    if (editBtn) {
        editBtn.addEventListener("click", () => {
            // Guarda el item current para editar
            localStorage.setItem("editingItem", JSON.stringify(selectedItem));
            window.location.href = "form.html";
        });
    }

    // Botón eliminar
    const deleteBtn = document.getElementById("delete-item");
    if (deleteBtn) {
        deleteBtn.addEventListener("click", async () => {
            // Borra imágenes del backend si existen
            const imagesToDelete = [];
            if (selectedItem.imageUrl) imagesToDelete.push(selectedItem.imageUrl);
            if (Array.isArray(selectedItem.secondaryImages)) {
                selectedItem.secondaryImages.forEach(img => imagesToDelete.push(img));
            }
            for (const imgPath of imagesToDelete) {
                try {
                    await fetch('http://localhost:3000/delete-image', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ imageUrl: imgPath })
                    });
                } catch (e) {
                    // Puedes mostrar un error si lo deseas, pero no detiene el flujo
                }
            }

            const inventory = JSON.parse(localStorage.getItem("inventory")) || [];
            const updatedInventory = inventory.filter(item => item.id !== selectedItem.id);
            localStorage.setItem("inventory", JSON.stringify(updatedInventory));
            alert("El objeto ha sido eliminado.");
            window.location.href = "index.html";
        });
    }

    // Botón volver (si existe)
    const backBtn = document.getElementById("back-to-inventory");
    if (backBtn) {
        backBtn.addEventListener("click", () => {
            window.location.href = "index.html";
        });
    }

    // Botón logout (si existe)
    const logoutBtn = document.getElementById("logout");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("isLoggedIn");
            window.location.href = "index.html";
        });
    }
});

// Función para ver detalles desde la lista principal
function verDetalles(itemId) {
    const inventory = JSON.parse(localStorage.getItem("inventory")) || [];
    const item = inventory.find(i => i.id === itemId);
    if (item) {
        localStorage.setItem("selectedItem", JSON.stringify(item));
        window.location.href = "details.html";
    }
}

// Redimensiona y comprime la imagen antes de convertirla a base64
function resizeImage(file, maxWidth = 600, maxHeight = 600, quality = 0.7) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        const reader = new FileReader();
        reader.onload = e => {
            img.src = e.target.result;
        };
        img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            if (width > maxWidth) {
                height *= maxWidth / width;
                width = maxWidth;
            }
            if (height > maxHeight) {
                width *= maxHeight / height;
                height = maxHeight;
            }
            canvas.width = width;
            canvas.height = height;
            canvas.getContext('2d').drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', quality));
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

const addSecondaryInput = document.getElementById("add-secondary-image-input");

if (addSecondaryInput) {
    addSecondaryInput.onchange = async function () {
        if (!this.files || !this.files[0]) return;
        const base64 = await resizeImage(this.files[0]);
        // ...agrega la imagen como antes...
    };
}

// Este archivo puede ser eliminado si no está siendo usado ni referenciado en tu HTML.
