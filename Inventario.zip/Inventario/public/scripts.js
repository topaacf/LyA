document.addEventListener("DOMContentLoaded", () => {
    // --- Agregar usuario admin adicional si no existe ---
    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    if (!usuarios.find(u => u.username === "administracion")) {
        usuarios.push({
            username: "administracion",
            password: "temporal2025",
            role: "admin"
        });
        localStorage.setItem("usuarios", JSON.stringify(usuarios));
    }

    // Mostrar u ocultar header/main según sesión
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const loginDiv = document.getElementById("login");
    const mainHeader = document.getElementById("main-header");
    const mainDiv = document.getElementById("main");

    if (isLoggedIn === "true") {
        if (loginDiv) loginDiv.style.display = "none";
        if (mainHeader) mainHeader.style.display = "block";
        if (mainDiv) mainDiv.style.display = "block";
    } else {
        if (loginDiv) loginDiv.style.display = "flex";
        if (mainHeader) mainHeader.style.display = "none";
        if (mainDiv) mainDiv.style.display = "none";
    }

    // Login
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
        loginForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            // Admin fijo
            if (username === "admin" && password === "1234") {
                localStorage.setItem("isLoggedIn", "true");
                localStorage.setItem("userRole", "admin");
                if (loginDiv) loginDiv.style.display = "none";
                if (mainHeader) mainHeader.style.display = "block";
                if (mainDiv) mainDiv.style.display = "block";
                mostrarMain();
                return;
            }

            // Buscar usuario en la lista de usuarios aprobados
            let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
            const user = usuarios.find(u => u.username === username && u.password === password);
            if (user) {
                localStorage.setItem("isLoggedIn", "true");
                localStorage.setItem("userRole", user.role);
                if (loginDiv) loginDiv.style.display = "none";
                if (mainHeader) mainHeader.style.display = "block";
                if (mainDiv) mainDiv.style.display = "block";
                mostrarMain();
            } else {
                // Si no existe, preguntar si quiere solicitar registro
                if (confirm("Usuario no encontrado o no aprobado. ¿Deseas solicitar una cuenta?")) {
                    solicitarRegistroUsuario(username, password);
                } else {
                    alert("Usuario o contraseña incorrectos.");
                }
            }
        });
    }

    // Toggle password visibility
    const passwordInput = document.getElementById("password");
    const togglePasswordBtn = document.getElementById("toggle-password");

    if (togglePasswordBtn && passwordInput) {
        // Mostrar contraseña mientras se mantiene presionado el botón
        togglePasswordBtn.addEventListener("mousedown", () => {
            passwordInput.type = "text";
        });
        togglePasswordBtn.addEventListener("mouseup", () => {
            passwordInput.type = "password";
        });
        togglePasswordBtn.addEventListener("mouseleave", () => {
            passwordInput.type = "password";
        });
        // Opcional: para accesibilidad con teclado
        togglePasswordBtn.addEventListener("touchstart", () => {
            passwordInput.type = "text";
        });
        togglePasswordBtn.addEventListener("touchend", () => {
            passwordInput.type = "password";
        });
    }

    // Logout
    const logoutBtn = document.getElementById("logout");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", function() {
            localStorage.removeItem("isLoggedIn");
            localStorage.removeItem("userRole");
            window.location.href = "index.html";
        });
    }

    // Botones de IA
    const aiSuggestionsBtn = document.getElementById("ai-suggestions");
    if (aiSuggestionsBtn) aiSuggestionsBtn.addEventListener("click", showOptimizationSuggestions);

    const aiReportBtn = document.getElementById("ai-report");
    if (aiReportBtn) aiReportBtn.addEventListener("click", showStatisticalReport);

    // Otros listeners...
    const exportCsvBtn = document.getElementById("export-csv");
    if (exportCsvBtn) exportCsvBtn.addEventListener("click", exportCSV);

    const addItemBtn = document.getElementById("add-item");
    if (addItemBtn) {
        addItemBtn.addEventListener("click", () => {
            localStorage.setItem("editingItem", null);
            window.location.href = "form.html";
        });
    }

    const reloadBtn = document.getElementById("reload");
    if (reloadBtn) reloadBtn.addEventListener("click", renderInventory);

    const showHistoryBtn = document.getElementById("show-history");
    if (showHistoryBtn) {
        showHistoryBtn.addEventListener("click", function() {
            const history = JSON.parse(localStorage.getItem("history")) || [];
            const historyConsole = document.getElementById("history-console");
            if (history.length === 0) {
                historyConsole.textContent = "No hay historial de cambios.";
            } else {
                historyConsole.textContent = history.map(
                    h => `[${h.fecha}] ${h.accion}: ${h.detalle}`
                ).reverse().join('\n');
            }
            document.getElementById("history-modal").style.display = "block";
        });
    }

    const closeHistoryBtn = document.getElementById("close-history");
    if (closeHistoryBtn) {
        closeHistoryBtn.addEventListener("click", () => {
            document.getElementById("history-modal").style.display = "none";
        });
    }

    window.addEventListener("click", (e) => {
        const historyModal = document.getElementById("history-modal");
        if (historyModal && e.target === historyModal) {
            historyModal.style.display = "none";
        }
    });

    // Filtros y render
    const searchInput = document.getElementById("search");
    if (searchInput) searchInput.addEventListener("input", renderInventory);

    const filterCondition = document.getElementById("filter-condition");
    if (filterCondition) filterCondition.addEventListener("change", renderInventory);

    const filterLocation = document.getElementById("filter-location");
    if (filterLocation) filterLocation.addEventListener("change", renderInventory);

    const sortSelect = document.getElementById("sort-select");
    if (sortSelect) {
        sortSelect.addEventListener("change", (e) => {
            sortBy = e.target.value === "alpha" ? "name" : e.target.value;
            renderInventory();
        });
    }

    renderInventory();

    if (localStorage.getItem("userRole") === "admin") {
        renderSolicitudesUsuarios();
        const solicitudesDiv = document.getElementById("user-requests");
        if (solicitudesDiv) solicitudesDiv.style.display = "block";
    } else {
        const solicitudesDiv = document.getElementById("user-requests");
        if (solicitudesDiv) solicitudesDiv.style.display = "none";
    }

    // Botón para solicitar registro redirige al formulario
    const solicitarBtn = document.getElementById("solicitar-registro");
    if (solicitarBtn) {
        solicitarBtn.addEventListener("click", function() {
            window.location.href = "registro.html";
        });
    }

    // Mostrar botón de solicitudes solo para admin
    const btnSolicitudes = document.getElementById("btn-solicitudes");
    if (btnSolicitudes) {
        if (localStorage.getItem("userRole") === "admin") {
            btnSolicitudes.style.display = "inline-block";
            btnSolicitudes.addEventListener("click", function() {
                window.location.href = "solicitudes.html";
            });
        } else {
            btnSolicitudes.style.display = "none";
        }
    }
});

// Chat IA OpenAI SOLO si existen los elementos (para evitar errores en index.html)
const aiChatSend = document.getElementById('ai-chat-send');
const aiChatInput = document.getElementById('ai-chat-input');
const aiChatMessages = document.getElementById('ai-chat-messages');
const aiChatContainer = document.getElementById('ai-chat-container');
const openAiChatBtn = document.getElementById('open-ai-chat');

if (openAiChatBtn && aiChatContainer) {
    openAiChatBtn.onclick = function() {
        aiChatContainer.style.display = aiChatContainer.style.display === 'block' ? 'none' : 'block';
    };
}

if (aiChatSend && aiChatInput && aiChatMessages) {
    aiChatSend.onclick = async function() {
        const userMsg = aiChatInput.value.trim();
        if (!userMsg) return;
        aiChatMessages.innerHTML += `<div class="user-msg" style="text-align:right;color:#2a9d8f;margin-bottom:6px;">${userMsg}</div>`;
        aiChatInput.value = '';
        aiChatMessages.innerHTML += `<div class="bot-msg" style="text-align:left;color:#264653;margin-bottom:6px;">Pensando...</div>`;
        aiChatMessages.scrollTop = aiChatMessages.scrollHeight;

        // Llama a la API de OpenAI
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer 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' // <-- PON AQUÍ TU API KEY
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{role: "user", content: userMsg}]
            })
        });
        const data = await response.json();
        // Elimina el "Pensando..."
        aiChatMessages.lastChild.remove();

        if (data.choices && data.choices[0] && data.choices[0].message) {
            aiChatMessages.innerHTML += `<div class="bot-msg" style="text-align:left;color:#264653;margin-bottom:6px;">${data.choices[0].message.content}</div>`;
        } else if (data.error && data.error.message) {
            aiChatMessages.innerHTML += `<div class="bot-msg" style="color:red;">Error: ${data.error.message}</div>`;
        } else {
            aiChatMessages.innerHTML += `<div class="bot-msg" style="color:red;">Error inesperado de la API.</div>`;
        }
        aiChatMessages.scrollTop = aiChatMessages.scrollHeight;
    };
}

// Variable sortBy debe declararse antes de usarla
let sortBy = null;

function renderInventory() {
    const grid = document.getElementById("inventory-grid");
    if (!grid) {
        // Evita el error si el elemento no existe
        console.warn('No se encontró el elemento con id "inventory-grid".');
        return;
    }
    const search = document.getElementById("search") ? document.getElementById("search").value.toLowerCase() : "";
    const filter = document.getElementById("filter-condition") ? document.getElementById("filter-condition").value : "";
    const locationFilter = document.getElementById("filter-location") ? document.getElementById("filter-location").value : "";
    let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
    let filtered = inventory.filter(item =>
        (item.name.toLowerCase().includes(search) || item.location.toLowerCase().includes(search)) &&
        (filter === "" || item.condition === filter) &&
        (locationFilter === "" || item.location === locationFilter)
    );
    if (sortBy) {
        filtered.sort((a, b) => a[sortBy].localeCompare(b[sortBy]));
    }
    grid.innerHTML = "";
    filtered.forEach(item => {
        const badgeClass = item.condition ? item.condition.toLowerCase() : "";
        const div = document.createElement("div");
        div.className = "item";
        const maxLocationLength = 38; // Ajusta según el ancho de tu card
        let locationText = item.location;
        let showMore = false;
        if (locationText && locationText.length > maxLocationLength) {
            locationText = locationText.slice(0, maxLocationLength - 3) + "...";
            showMore = true;
        }
        div.innerHTML = `
            <span class="badge ${badgeClass}">${item.condition}</span>
            <img src="${item.imageUrl || 'https://via.placeholder.com/90'}" alt="${item.name}">
            <h3>${item.name}</h3>
            <p style="color: black; font-weight: bold;">Código: ${item.code || "Sin código"}</p>
            <p style="text-align:center; color:#007b8a; margin: 8px 0 0 0;">
                <b>Usuario:</b> <span style="color:#009688;">${item.usuario || "Sin usuario asignado"}</span>
            </p>
            <p style="text-align:center; color:#666; margin: 8px 0 0 0;">
                <b>Ubicación:</b> <span style="color:#444;">${locationText}</span>
                ${showMore ? `<a href="#" class="show-more-location" data-id="${item.id}" style="color:#007b8a;font-weight:600;text-decoration:underline;cursor:pointer;">más..</a>` : ""}
            </p>
            <button class="view-details" data-id="${item.id}">Ver Detalles</button>
            ${localStorage.getItem("userRole") !== "read" ? `
                <button class="edit-item" data-id="${item.id}">Editar</button>
            ` : ""}
        `;
        div.querySelector(".view-details").addEventListener("click", () => {
            localStorage.setItem("selectedItem", JSON.stringify(item));
            window.location.href = "details.html";
        });
        // Listener para "más.."
        if (showMore) {
            div.querySelector(".show-more-location").addEventListener("click", (e) => {
                e.preventDefault();
                localStorage.setItem("selectedItem", JSON.stringify(item));
                window.location.href = "details.html";
            });
        }
        grid.appendChild(div);
    });
    const inventoryCount = document.getElementById("inventory-count");
    if (inventoryCount) {
        inventoryCount.textContent = `Total: ${filtered.length} mobiliarios`;
    }

    // Actualizar filtro de ubicaciones
    const locations = [...new Set(inventory.map(i => i.location))];
    const filterLocation = document.getElementById("filter-location");
    if (filterLocation) {
        filterLocation.innerHTML = '<option value="">Todas las ubicaciones</option>' +
            locations.map(loc => `<option value="${loc}">${loc}</option>`).join('');
    }

    // Agrega listeners a los botones de editar
    document.querySelectorAll('.edit-item').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            abrirFormularioEdicion(id);
        });
    });
}

// Mensaje de éxito
function showMessage(msg) {
    const el = document.getElementById("message");
    if (el) {
        el.textContent = msg;
        setTimeout(() => el.textContent = "", 2500);
    }
}

// Exportar a CSV
function exportCSV() {
    let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
    let csv = "Nombre,Ubicación,Estado\n" + inventory.map(i =>
        `"${i.name}","${i.location}","${i.condition}"`
    ).join("\n");
    let blob = new Blob([csv], { type: "text/csv" });
    let url = URL.createObjectURL(blob);
    let a = document.createElement("a");
    a.href = url;
    a.download = "inventario.csv";
    a.click();
    URL.revokeObjectURL(url);
}

// Historial de cambios (ejemplo)
function addHistory(action) {
    let history = JSON.parse(localStorage.getItem("history")) || [];
    history.unshift({ action, date: new Date().toLocaleString() });
    if (history.length > 30) history = history.slice(0, 30);
    localStorage.setItem("history", JSON.stringify(history));
}

function renderHistoryConsole() {
    let history = JSON.parse(localStorage.getItem("history")) || [];
    const consoleEl = document.getElementById("history-console");
    if (consoleEl) {
        if (history.length === 0) {
            consoleEl.textContent = "Sin cambios recientes.";
        } else {
            consoleEl.textContent = history.map(h => `[${h.date}] ${h.action}`).join('\n');
        }
    }
}

// Sugerencias de optimización
function getOptimizationSuggestions() {
    let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
    let suggestions = [];
    const malos = inventory.filter(i => i.condition === "Malo");
    if (malos.length > 0) {
        suggestions.push(`Reemplazar o reparar ${malos.length} mobiliario(s) en mal estado.`);
    }
    let locationStats = {};
    inventory.forEach(i => {
        if (!locationStats[i.location]) locationStats[i.location] = { total: 0, malos: 0 };
        locationStats[i.location].total++;
        if (i.condition === "Malo") locationStats[i.location].malos++;
    });
    Object.entries(locationStats).forEach(([loc, stats]) => {
        if (stats.malos / stats.total > 0.5) {
            suggestions.push(`La ubicación "${loc}" tiene más del 50% de mobiliario en mal estado.`);
        }
        if (stats.total > 10) {
            suggestions.push(`La ubicación "${loc}" tiene más de 10 mobiliarios. Considera redistribuir.`);
        }
    });
    return suggestions.length ? suggestions : ["No se detectaron acciones prioritarias."];
}

function showOptimizationSuggestions() {
    const suggestions = getOptimizationSuggestions();
    alert("Sugerencias de Optimización:\n\n" + suggestions.join('\n'));
}

// Reporte estadístico
function generateStatisticalReport() {
    let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
    let total = inventory.length;
    let byCondition = {};
    let byLocation = {};
    inventory.forEach(i => {
        byCondition[i.condition] = (byCondition[i.condition] || 0) + 1;
        byLocation[i.location] = (byLocation[i.location] || 0) + 1;
    });
    let report = `REPORTE ESTADÍSTICO DEL INVENTARIO\n\nTotal de mobiliarios: ${total}\n\nPorcentaje por estado:\n`;
    Object.entries(byCondition).forEach(([cond, count]) => {
        report += `- ${cond}: ${((count / total) * 100).toFixed(1)}% (${count})\n`;
    });
    report += `\nTop 3 ubicaciones con más mobiliario:\n`;
    Object.entries(byLocation)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .forEach(([loc, count]) => {
            report += `- ${loc}: ${count}\n`;
        });
    report += `\nMobiliario en mal estado (posible baja contable): ${byCondition["Malo"] || 0}\n`;
    return report;
}

function showStatisticalReport() {
    const report = generateStatisticalReport();
    alert(report);
}

// Ejemplo de integración IA (requiere backend)
async function obtenerSugerenciasIA() {
    const inventario = JSON.parse(localStorage.getItem("inventory")) || [];
    const res = await fetch("http://localhost:3000/ia/sugerencias", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ inventario })
    });
    const data = await res.json();
    alert("Sugerencias IA:\n\n" + data.sugerencias);
}

// Función para solicitar registro de usuario
function solicitarRegistroUsuario(username, password) {
    let solicitudes = JSON.parse(localStorage.getItem("userRequests")) || [];
    solicitudes.push({
        username,
        password,
        status: "pendiente"
    });
    localStorage.setItem("userRequests", JSON.stringify(solicitudes));
    alert("Solicitud enviada. Un administrador debe aprobar tu cuenta.");
}

// Función para renderizar solicitudes (solo admin)
function renderSolicitudesUsuarios() {
    const solicitudes = JSON.parse(localStorage.getItem("userRequests")) || [];
    const solicitudesDiv = document.getElementById("user-requests");
    if (!solicitudesDiv) return;
    if (solicitudes.length === 0) {
        solicitudesDiv.innerHTML += "<p>No hay solicitudes pendientes.</p>";
        return;
    }
    solicitudes.forEach((sol, idx) => {
        if (sol.status === "pendiente") {
            solicitudesDiv.innerHTML += `
                <div style="border:1px solid #ccc; margin:8px 0; padding:8px;">
                    <b>Usuario:</b> ${sol.username}<br>
                    <label>Rol:
                        <select id="rol-select-${idx}">
                            <option value="editor">Editor</option>
                            <option value="read">Lector</option>
                        </select>
                    </label>
                    <button onclick="aprobarUsuario(${idx})">Aprobar</button>
                    <button onclick="denegarUsuario(${idx})">Denegar</button>
                </div>
            `;
        }
    });
}

// Función para aprobar usuario
window.aprobarUsuario = function(idx) {
    let solicitudes = JSON.parse(localStorage.getItem("userRequests")) || [];
    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    const solicitud = solicitudes[idx];
    const rol = document.getElementById(`rol-select-${idx}`).value;
    usuarios.push({
        username: solicitud.username,
        password: solicitud.password,
        role: rol
    });
    solicitudes[idx].status = "aprobada";
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
    localStorage.setItem("userRequests", JSON.stringify(solicitudes));
    renderSolicitudesUsuarios();
    alert("Usuario aprobado y creado.");
};

// Función para denegar usuario
window.denegarUsuario = function(idx) {
    let solicitudes = JSON.parse(localStorage.getItem("userRequests")) || [];
    solicitudes[idx].status = "denegada";
    localStorage.setItem("userRequests", JSON.stringify(solicitudes));
    renderSolicitudesUsuarios();
    alert("Solicitud denegada.");
};

function abrirFormularioEdicion(id) {
    const inventory = JSON.parse(localStorage.getItem("inventory")) || [];
    const item = inventory.find(i => i.id == id);
    if (!item) {
        alert("Mobiliario no encontrado.");
        return;
    }
    // Guarda el item en edición en localStorage y redirige al formulario
    localStorage.setItem("editingItem", JSON.stringify(item));
    window.location.href = "form.html";
}

function mostrarMain() {
    document.getElementById("login").style.display = "none";
    document.getElementById("main").style.display = "block";
    renderInventory(); // Solo aquí se llama, cuando el div ya existe y es visible
}

