const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Permitir peticiones desde el frontend
app.use(cors());
app.use(express.static('public'));

// Configuración de almacenamiento de multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'public', 'imagenes'));
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});
const upload = multer({ storage: storage });

// Ruta para subir imágenes
app.post('/upload', upload.single('image'), (req, res) => {
  res.json({ imageUrl: 'imagenes/' + req.file.originalname });
});

// Ruta para borrar imágenes
app.post('/delete-image', express.json(), (req, res) => {
  const { imageUrl } = req.body;
  if (!imageUrl) return res.status(400).json({ error: 'No imageUrl provided' });
  const imagePath = path.join(__dirname, 'public', imageUrl);
  fs.unlink(imagePath, err => {
    if (err) {
      // Si el archivo no existe, no es un error fatal
      return res.status(200).json({ deleted: false, message: 'File not found or already deleted' });
    }
    res.json({ deleted: true });
  });
});

app.listen(PORT, () => {
  console.log(`Servidor backend corriendo en http://localhost:${PORT}`);
});