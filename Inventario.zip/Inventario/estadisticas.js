// Ruta para chat de estadísticas
app.post("/ia/estadisticas", async (req, res) => {
    const { inventario, question } = req.body;
    const prompt = `
Eres un experto en análisis de inventarios. Solo responde preguntas sobre estadísticas del siguiente inventario. Si la pregunta no es de estadísticas, pide que se limite a ese tema. Si necesitas más datos, pídelos.
Inventario: ${JSON.stringify(inventario)}
Pregunta: ${question}
Respuesta:`;
    const completion = await openai.createChatCompletion({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }]
    });
    res.json({ respuesta: completion.data.choices[0].message.content });
});

// Ruta para chat de sugerencias/consejos
app.post("/ia/sugerencias", async (req, res) => {
    const { inventario, question } = req.body;
    const prompt = `
Eres un asesor de optimización de inventarios. Solo responde preguntas sobre consejos, optimización y mejoras del siguiente inventario. Si la pregunta no es de consejos, pide que se limite a ese tema. Si necesitas más datos, pídelos.
Inventario: ${JSON.stringify(inventario)}
Pregunta: ${question}
Respuesta:`;
    const completion = await openai.createChatCompletion({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }]
    });
    res.json({ respuesta: completion.data.choices[0].message.content });
});